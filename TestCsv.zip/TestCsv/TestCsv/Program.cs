﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCsv
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int n = Convert.ToInt32(Console.ReadLine());
            int increm = n;
            int fileNumber = 1;   //for generating file names
            string pathNewCsv = @"C:\Users\alexandru.zdru\Desktop\info\info" + fileNumber++ + ".csv";
            
            var temp = File.ReadAllLines(@"C:\Users\alexandru.zdru\Desktop\inform.csv");
            int i = 0;     //column number to start
            while (i < temp[0].Split(';').Length-1)
            {
                string notepad = string.Empty;
                foreach (string line in temp)
                {
                    int j = i;
                    var delimitedLine = line.Split(';'); //set separator, in this case ;                    
                    while (j < n && j<delimitedLine.Length-1)
                    {
                        notepad = notepad + delimitedLine[j] + ";";
                        Console.Write(delimitedLine[j] + ";");
                        j++;
                    }                                     
                    Console.WriteLine();
                    notepad = notepad + Environment.NewLine;
                }
                File.WriteAllText(pathNewCsv, notepad);
                i += increm;
                n += increm;
                pathNewCsv = @"C:\Users\alexandru.zdru\Desktop\info\info" + fileNumber++ + ".csv";                
                Console.ReadLine();
            }                
        }
    }
}
