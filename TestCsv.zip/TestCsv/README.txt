reads a csv file and splits it into multiple csv files by the entered number of columns,
each one containing the number of columns specified