﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace InverseWordOrder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> words = new List<string>();

            Console.WriteLine("Enter a string :");
            string input = Console.ReadLine();
            string word_pattern = @"\b\w+";
            string marks_pattern = @"[.,+-]";
            string output = string.Empty;
            string regexYtd = @"\W*((?i)ytd(?-i))\W*";

            Match match = Regex.Match(input, word_pattern);
            while (match.Success != false)
            {

                    Console.WriteLine("Word matched: "+match.Value);

                    words.Add(match.Value);
                    input = input.Replace(match.Value, "");
                    match = Regex.Match(input, word_pattern);
            }
            for(int i=words.Count-1; i>=0; i--)
            {
                output += words[i] + " ";
            }
            output += " ";
            output.Replace("  ", "");
            Console.WriteLine("Your reverse word order  string is: "+ output);
            Console.ReadLine();
        }
        public static string Reverse(string s)
        {
            var result = new string(s.ToCharArray().Reverse().ToArray());
            return result;
        }
    }
        
}
