﻿namespace WorkshopAPI
{
    public static class Globals
    {
        public static string ConnectionString = "Server=WILSQL1;Database=DesktopApps;User Id=id;Password=password";
        public static string namePattern = "^[A-Z]{1}[A-Za-z]{3,}$";
        public static string emailPattern = "^[a-zA-Z]+[.+-_]{0,1}[0-9a-zA-Z]+[@][a-zA-Z]+[.]+[a-zA-Z]{2,4}([a-zA-z]{2,4}){0,1}";
        public static string phonePattern = "^[0]{1}[0-9]{9}$";
    }
}
