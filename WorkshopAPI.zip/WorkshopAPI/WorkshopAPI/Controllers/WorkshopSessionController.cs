﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WorkshopAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class WorkshopSessionController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<List<WorkshopSession>>> GetSessions()
        {
            DataAccess db = new DataAccess();
            return Ok(await db.GetSessionsAsync());
        }
        [HttpGet]
        public async Task<ActionResult<List<WorkshopSession>>> GetAvailable()
        {
            DataAccess db = new DataAccess();
            return Ok(await db.GetAvailableSessionsAsync());
        }

        [HttpGet]
        public async Task<ActionResult<List<WorkshopSession>>> GetAvailableForPeriod(DateTime startDate, DateTime endDate)
        {
            DataAccess db = new DataAccess();
            return Ok(await db.GetAvailableSessionsPeriodAsync(startDate, endDate));
        }
        [HttpGet]
        public async Task<ActionResult<List<WorkshopSession>>> GetAvailableForDay(DateTime date)
        {
            DataAccess db = new DataAccess();
            return Ok(await db.GetAvailableSessionsForDayAsync(date));
        }
        [HttpGet]
        public async Task<ActionResult<List<WorkshopSession>>> GetAvailableForId(int wsId)
        {
            DataAccess db = new DataAccess();
            if(await db.GetAvailableSessionByIdAsync(wsId) == null)
                return Ok("Unfortunately we have no workshop session available for the selected day");
            return Ok(await db.GetAvailableSessionByIdAsync(wsId));
        }

    }
}
