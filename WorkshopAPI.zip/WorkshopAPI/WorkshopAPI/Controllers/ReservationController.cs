﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;

namespace WorkshopAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<List<Reservation>>> GetAllReservations()
        {
            DataAccess db = new DataAccess();
            return (await db.GetReservationsAsync());
        }
        [HttpGet]
        public async Task<ActionResult<List<Reservation>>> GetReservationForSpecificUser(int userId)
        {
            DataAccess db = new DataAccess();
            return (await db.GetReservationsByUserIdAsync(userId));
        }
        [HttpGet]
        public async Task<ActionResult<List<Reservation>>> GetReservationForUserOnPeriod(int userId, DateTime startDate, DateTime endDate)
        {            
            if (startDate >= endDate || startDate == null || endDate == null)
                return BadRequest("Check if start date is earlier than end date or if any of them is null.");
            DataAccess db = new DataAccess();
            var users = await db.GetUsersAsync();
            var user = users.Find(u => u.Id == userId);
            if (user == null)
                return NotFound("User not found.");
            return (await db.GetReservationsForUserPeriodAsync(userId, startDate, endDate));
        }

        [HttpPost]
        public async Task<ActionResult<List<Reservation>>> CreateReservation(int wsessionId, string fname, string lname, string email, string phone, string address)
        {
            if (!Regex.IsMatch(fname, Globals.namePattern))
                return BadRequest("Incorrect First Name.");

            if (!Regex.IsMatch(lname, Globals.namePattern))
                return BadRequest("Incorrect Last Name.");

            if (!Regex.IsMatch(email, Globals.emailPattern))
                return BadRequest("Incorrect email address.");

            if (!Regex.IsMatch(phone, Globals.phonePattern))
                return BadRequest("Incorrect phone number.");

            DataAccess db = new DataAccess();  
            var sessions = db.GetSessionsAsync().Result.ToList();
            var session = sessions.Find(s => s.Id == wsessionId);

            if (session != null)
            {
                if (session.Participants == session.MaxParticipants)
                    return Ok("There are no places left for this session. Please try another one");
                if (session.Scheduled < DateTime.Now)
                    return Ok("Unfortunately the workshop session is past.");

                session.Participants++;
                await db.UpdateSessionParticipants(session.Id, session.Participants);
                var users = db.GetUsersAsync().Result.ToList();
                var user = users.Find(u => u.Phone == phone);
                if (user != null)
                {
                    await db.AddReservationAsync(wsessionId, fname, lname, email, phone, address, user.Id);
                    user.reservations = await db.GetReservationsByUserIdAsync(user.Id);
                    return Ok(user.reservations);
                }
                else
                {
                    await db.AddUserAsync(fname, lname, email, phone, address);
                    int newUserId = await db.GetLastUserIdAsync();
                    await db.AddReservationAsync(wsessionId, fname, lname, email, phone, address, newUserId);
                    return Ok(await db.GetLastReservationAsync());
                }
            }                        
            else
                return Ok("The session is not available. Check Id.");            
        }
        [HttpDelete]
        public async Task<ActionResult<List<Reservation>>> DeleteReservationForUser(int userId, int wsessionId)
        {
            DataAccess db = new DataAccess();
            await db.DeleteReservationAsync(userId, wsessionId);
            var session = db.GetSessionByIdAsync(wsessionId).Result;
            session.Participants--;
            await db.UpdateSessionParticipants(session.Id, session.Participants);
            
            return Ok(await db.GetReservationsByUserIdAsync(userId));
        }
    }
}
