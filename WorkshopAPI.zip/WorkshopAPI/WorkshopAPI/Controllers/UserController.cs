﻿using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;

namespace WorkshopAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<List<User>>> GetUsers()
        {
            DataAccess db = new DataAccess();
            return Ok(await db.GetUsersAsync());
        }
        [HttpPost]
        public async Task<ActionResult<List<User>>> PostUser(string fname, string lname, string email, string phone, string address)
        {
            if (!Regex.IsMatch(fname, Globals.namePattern))
                return BadRequest("Incorrect First Name.");

            if (!Regex.IsMatch(lname, Globals.namePattern))
                return BadRequest("Incorrect Last Name.");

            if (!Regex.IsMatch(email, Globals.emailPattern))
                return BadRequest("Incorrect email address.");

            if (!Regex.IsMatch(phone, Globals.phonePattern))
                return BadRequest("Incorrect phone number.");

            DataAccess db = new DataAccess();
            await db.AddUserAsync(fname, lname, email, phone, address);
            return Ok(await db.GetUsersAsync());
        }

        [HttpDelete]
        public async Task<ActionResult<List<User>>> DeleteUser(int u_id)
        {
            DataAccess db = new DataAccess();
            var users = await db.GetUsersAsync();
            var user = users.Find(u => u.Id == u_id);
            if (user == null)
                return BadRequest("User not found.");

            await db.DeleteUserAsync(u_id);
            return Ok(await db.GetUsersAsync());
        }
    }
}
