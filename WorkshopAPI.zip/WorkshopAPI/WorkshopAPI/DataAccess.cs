﻿using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace WorkshopAPI
{
    public class DataAccess
    {
        public async Task<List<WorkshopSession>> GetSessionsAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions");
                return output.ToList();
            }
        }
        public async Task<WorkshopSession> GetSessionByIdAsync(int wsId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions where id = '{wsId}'");
                return output.ToList()[0];
            }
        }
        public async Task<List<WorkshopSession>> GetAvailableSessionsAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions where participants < maxparticipants AND SCHEDULED > '{DateTime.Now}'");
                return output.ToList();
            }
        }
        public async Task<List<WorkshopSession>> GetAvailableSessionsPeriodAsync(DateTime startDate, DateTime endDate)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions where participants < maxparticipants AND SCHEDULED > '{startDate}' AND SCHEDULED < '{endDate}'");
                return output.ToList();
            }
        }
        public async Task<List<WorkshopSession>> GetAvailableSessionsForDayAsync(DateTime date)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var result = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions where participants < maxparticipants");
                List<WorkshopSession> output = new List<WorkshopSession>();
                foreach (WorkshopSession session in result)
                {
                    if (session.Scheduled.Year == date.Year && session.Scheduled.Month == date.Month && session.Scheduled.Day == date.Day)
                        output.Add(session);
                }
                return output.ToList();
            }
        }
        public async Task<List<WorkshopSession>> GetAvailableSessionByIdAsync(int wsId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<WorkshopSession>($"select * from alextask.WorkshopSessions where participants < maxparticipants AND SCHEDULED > '{DateTime.Now}' AND id = '{wsId}'");
                return output.ToList();
            }
        }
        public async Task UpdateSessionParticipants(int wsId, int newParticipantsNumber)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {                            
                await connection.ExecuteAsync($"UPDATE alextask.WorkshopSessions SET participants = '{newParticipantsNumber}' WHERE id = '{wsId}'");
            }
            
        }
        public async Task<int> GetLastUserIdAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<int>($"SELECT TOP 1 id FROM alextask.Users ORDER BY id DESC");
                return output.ToList()[0];
            }
        }
        public async Task<List<User>> GetUsersAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var result = await connection.QueryAsync<User>($"select * from alextask.Users");
                foreach (var user in result)
                {
                    user.reservations = await GetReservationsByUserIdAsync(user.Id);
                }
                return result.ToList();
                
            }
        }
        public async Task<List<User>> GetUserByIdAsync(int userId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<User>($"select * from alextask.Users where id = '{userId}'");
                return output.ToList();
            }
        }
        public async Task<User> GetUserByPhoneNumberAsync(string phone)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<User>($"SELECT TOP 1 * FROM alextask.Users where phone = '{phone}'");
                return output.ToList()[0];
            }
        }

        public async Task AddUserAsync(string fname, string lname, string email, string phone, string address)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                await connection.ExecuteAsync("insert into alextask.Users(fname,lname,email,phone,address) values (@fname,@lname,@email,@phone,@address)", new { fname, lname, email, phone, address });
            }
        }
        public async Task DeleteUserAsync(int userId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                await connection.ExecuteAsync($"delete from alextask.Users where u_id = '{userId}'");
            }
        }
        public async Task<List<Reservation>> GetReservationsAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<Reservation>($"select * from alextask.Reservations");
                return output.ToList();
            }
        }
        public async Task<Reservation> GetLastReservationAsync()
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<Reservation>($"SELECT TOP 1 * FROM alextask.Reservations ORDER BY id DESC");
                return output.ToList()[0];
            }
        }
        public async Task<List<Reservation>> GetReservationsByUserIdAsync(int userId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                var output = await connection.QueryAsync<Reservation>($"select * from alextask.Reservations where userId = '{userId}'");
                return output.ToList();
            }
        }
        public async Task<List<Reservation>> GetReservationsForUserPeriodAsync(int userId, DateTime startDate, DateTime endDate)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                List<WorkshopSession> allsessions = new List<WorkshopSession>();
                allsessions = await GetSessionsAsync();
                List<WorkshopSession> usessions = new List<WorkshopSession>();
                List<Reservation> reservals = new List<Reservation>();
                List<Reservation> output = new List<Reservation>();
                var result = await connection.QueryAsync<Reservation>($"SELECT * FROM alextask.Reservations where userId = '{userId}'");
                reservals = result.ToList();
                foreach (var reservation in reservals)
                {
                    foreach (var session in allsessions)
                    {
                        if (reservation.WsessionId == session.Id)
                            usessions.Add(session);
                    }
                }
                foreach (var session in usessions)
                {
                    if (session.Scheduled >= startDate && session.Scheduled <= endDate)
                    {
                        var res = reservals.Find(r => r.WsessionId == session.Id);
                        output.Add(res);
                    }
                }
                return output.ToList();
            }
        }
        public async Task AddReservationAsync(int wsessionId, string fname, string lname, string email, string phone, string address, int userId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                await connection.ExecuteAsync("insert into alextask.Reservations(wsessionId,fname,lname,email,phone,address,userId) " +
                    "values (@wsessionId,@fname,@lname,@email,@phone,@address, @userId)", new { wsessionId, fname, lname, email, phone, address, userId });
            }
        }
        public async Task DeleteReservationAsync(int userId, int wsessionId)
        {
            using (IDbConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                await connection.ExecuteAsync($"delete from alextask.Reservations where id = '{userId}' AND wsessionId = '{wsessionId}'");
            }
        }
    }
}
