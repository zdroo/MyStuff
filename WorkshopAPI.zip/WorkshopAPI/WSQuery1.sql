CREATE TABLE alextask.WorkshopSessions(
id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
name varchar (30),
description varchar(50),
participants int,
maxparticipants int,
scheduled SMALLDATETIME,
); 

CREATE TABLE alextask.Reservations(
id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
wsessionId int,
fname varchar (30),
lname varchar(30),
email varchar(30),
phone varchar(12),
address varchar(50),
userId int,
FOREIGN KEY(userId) REFERENCES alextask.Users(id) ON DELETE SET NULL,
FOREIGN KEY(wsessionId) REFERENCES alextask.WorkshopSessions(id) ON DELETE SET NULL
);

CREATE TABLE alextask.Users(
id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
fname varchar (30),
lname varchar(30),
email varchar(30),
phone varchar(12),
address varchar(50)
);

INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled) 
values('cooking','cooking workshop',1,5,'2022-03-01 9:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('crosetat','confectionare obiecte din tesaturi',2,5,'2022-03-01 11:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('lut','modelat lut',5,5,'2022-03-01 13:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('mecanica','mecanica auto cu exemple si demonstratii',1,5,'2022-03-01 15:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('tamplarie','confectionare obiecte din lemn',4,5,'2022-02-07 13:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('cigar','confectionare trabucuri',4,5,'2021-06-14 13:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('acarete','confectionare acarete',4,5,'2022-02-25 09:00')
INSERT INTO alextask.WorkshopSessions(name, description,participants,maxparticipants,scheduled)
values('icoane','pictat icoane',4,5,'2022-02-25 11:00')

--SELECT * FROM alextask.WorkshopSessions
--select * from alextask.Reservations
--select * from alextask.Users