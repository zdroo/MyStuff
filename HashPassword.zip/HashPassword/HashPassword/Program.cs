﻿using System;

namespace HashPassword
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var password = Globals.HashPassword("malone");
            //Console.WriteLine(password);
            Console.WriteLine("Introduce your password: ");
            var pass = Console.ReadLine();
            var hashedPass = PasswordHashPBKDF2.HashPassword(pass);
            Console.WriteLine(hashedPass);

            Console.WriteLine(PasswordHashPBKDF2.ValidatePassword("parola", hashedPass));
            Console.ReadLine();

        }
    }
}
