﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RegexValidation1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name_regex = "^[A-Z]{1}[A-Za-z]{3,}$";
            string mobile_regex = "^[0]{1}[0-9]{9}$";
            string email_regex = "^[a-zA-Z]+[.+-_]{0,1}[0-9a-zA-Z]+[@][a-zA-Z]+[.]+[a-zA-Z]{2,4}([a-zA-z]{2,4}){0,1}";
            string password_regex = "^[a-zA-Z0-9]{8,}";
            string cnp_regex = "^[1,2,3,4,5,6]{1}[0-9]{12}";
            string ci_regex = "^[A-Z]{2}[0-9]{6}$";

            Console.WriteLine("Name validation:");
            Console.WriteLine(Regex.IsMatch("Alexander", name_regex));

            Console.WriteLine("Mobile validation:");
            Console.WriteLine(Regex.IsMatch("0770330812", mobile_regex));

            Console.WriteLine("Email validation:");
            Console.WriteLine(Regex.IsMatch("alexandru.zdru@toluna.com", email_regex));

            Console.WriteLine("Password validation:");
            Console.WriteLine(Regex.IsMatch("Balotesti1", password_regex));

            Console.WriteLine("CNP validation:");
            Console.WriteLine(Regex.IsMatch("1990106655222", cnp_regex));

            Console.WriteLine("Identity Card series and number validation:");
            Console.WriteLine(Regex.IsMatch("RK661235", ci_regex));

            Console.ReadLine(); 



        }
    }
}
