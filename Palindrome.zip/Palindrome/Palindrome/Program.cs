﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input, reverse = string.Empty;
            Console.Write("Enter a string : ");
            input = Console.ReadLine();
            if (input != null)
            {
                for (int i = input.Length - 1; i >= 0; i--)
                {
                    reverse += input[i].ToString();
                }
                if (reverse == input)
                {
                    Console.WriteLine("String is Palindrome\nInput = {0} and Output = {1}", input, reverse);
                }
                else
                {
                    Console.WriteLine("String is not a Palindrome\nInput = {0} and Output = {1}", input, reverse);
                }
            }
            Console.ReadLine();
        }
    }
}
