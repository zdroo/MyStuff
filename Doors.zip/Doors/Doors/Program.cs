﻿using System;

namespace Doors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int choice, secondChoice, wrong;
            char decision;

            Random rnd = new Random();
            int correct = rnd.Next(1, 4);

            Console.WriteLine("Enter your guess: 1, 2 or 3");
            choice = Convert.ToInt32(Console.ReadLine().ToString());

            do
            {
                wrong = rnd.Next(1, 4);
            } while (wrong == choice || wrong == correct);
            Console.WriteLine("There is nothing behind door number " + wrong);

            do
            {
                secondChoice = rnd.Next(1, 4);
            } while (secondChoice == choice || secondChoice == wrong);

            Console.WriteLine("Would you like to switch to door number " + secondChoice + "?   y/n");
            decision = Console.ReadLine()[0];

            switch (decision)
            {
                case 'y':
                    choice = secondChoice;
                    break;

                case 'n':
                    break;

                default:
                    Console.WriteLine("Invalid input");
                    break;
            }

            if (choice == correct)
            {
                Console.WriteLine(@"Your guess is correct!
The object is behind door number " + correct);
                Console.WriteLine("Press any key to exit");
            }

            else
            {
                Console.WriteLine(@"Your guess is wrong!
The object is behind door number " + correct);
                Console.WriteLine("Press any key to exit");
            }

            Console.ReadLine();

        }
    }
}
